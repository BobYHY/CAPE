import torch
import numpy as np
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error, mean_squared_error


def compute_score(prediction, target):
    # inputs are torch.tensor, we transform them to np.array (in cpu)
    prediction = prediction.detach().cpu().numpy().reshape(-1)
    target = target.detach().cpu().numpy().reshape(-1)
    corr = np.corrcoef(prediction, target)
    return [corr[0, 1],mean_absolute_error(prediction,target),mean_squared_error(prediction,target)]

def train_one_epoch(model, optimizer, criterion, data_loader, device):

    model.train()
    epoch_loss = 0
    for i, data in enumerate(data_loader):

        seq_data, pssm_data, labels = data['dna'], data['pssm'], data['labels']
        seq_data = seq_data.to(device)
        pssm_data = pssm_data.to(device)
        labels = labels.to(device)

        # Forward pass
        outputs = model(seq_data, pssm_data)
        loss = criterion(outputs, labels)

        # Backward and optimize
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()


        epoch_loss += loss.item()

    return epoch_loss / len(data_loader)


@torch.no_grad()
def evaluate(model, data_loader, criterion, device):

    model.eval()
    epoch_loss = 0
    eval_acc = 0
    eval_mse= 0
    eval_mae=0
    R2=0
    for i, data in enumerate(data_loader):
        seq_data, pssm_data, labels = data['dna'], data['pssm'], data['labels']
        seq_data = seq_data.to(device)
        pssm_data = pssm_data.to(device)
        labels = labels.to(device)

        # Forward pass
        outputs = model(seq_data, pssm_data)
        loss = criterion(outputs, labels)

        epoch_loss += loss.item()

        # Compute corr
        ACC,MAE,MSE=compute_score(prediction=outputs, target=labels)
        eval_acc += ACC
        eval_mse += MSE
        eval_mae += MAE
        out = outputs.detach().cpu().numpy().reshape(-1)
        real = labels.detach().cpu().numpy().reshape(-1)
        R2+=r2_score(real,out)

    return epoch_loss / len(data_loader), eval_acc / len(data_loader), R2 / len(data_loader), eval_mse, eval_mae

