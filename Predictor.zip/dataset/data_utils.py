import numpy as np
import torch
from torch.utils.data import Dataset
from sklearn.model_selection import train_test_split

class PromoterDataset(Dataset):
    def __init__(self, text, pssm, labels):
        self.text = torch.from_numpy(text).float()
        self.pssm = torch.from_numpy(pssm).unsqueeze(1) 
        self.labels = torch.from_numpy(labels).unsqueeze(-1)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        content = {'dna': self.text[idx],
                   'pssm': self.pssm[idx],
                   'labels': self.labels[idx]}
        return content

def data_preprocessing(path_x, path_pssm, path_y, path_w2v, K=3):
    x = np.load(path_x)
    y = np.load(path_y)
    wv = np.load(path_w2v, allow_pickle = True).item()
    pssm = np.load(path_pssm).astype(np.float32)
    x1 = []
    for i in range(0, len(x)):
        x2 = []
        for j in range(0, len(x[i]) - K + 1):
            x2.append(wv[x[i][j:j + K]])
        x1.append(x2)
    X = np.array(x1).astype(np.float32)
    y= np.array(y).astype(np.float32)
    y= np.log2(y+1e-5)
    return X, pssm, y

def get_dataset(path_x, path_pssm, path_y, path_w2v, val_percentage, State=0):
    X, pssm, y = data_preprocessing(path_x, path_pssm, path_y, path_w2v)
    X_used, y_used, pssm_used = X[:11884], y[:11884], pssm[:11884]
    X_train, X_val, y_train, y_val = train_test_split(X_used, y_used, test_size=val_percentage, random_state=State)
    pssm_train, pssm_val = train_test_split(pssm_used, test_size=val_percentage, random_state=State)

    train_dataset = PromoterDataset(text=X_train, pssm = pssm_train, labels=y_train)
    val_dataset = PromoterDataset(text=X_val, pssm= pssm_val, labels=y_val)

    return train_dataset, val_dataset

def get_test_dataset(path_x, path_pssm, path_y, path_w2v, test_percentage, State=0):
    X, pssm, y = data_preprocessing(path_x, path_pssm, path_y, path_w2v)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_percentage, random_state=State)
    pssm_train, pssm_val = train_test_split(pssm, test_size=test_percentage, random_state=State)

    train_dataset = PromoterDataset(text=X_train, pssm = pssm_train, labels=y_train)
    test_dataset = PromoterDataset(text=X_test, pssm= pssm_val, labels=y_test)

    return train_dataset, test_dataset

