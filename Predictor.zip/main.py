from model.promoter_model import PrompterModel
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch.utils.data import DataLoader
from dataset.data_utils import get_dataset, get_test_dataset
from dataset.matrix import matrix_generation
from train_and_val.train_eval_utils import train_one_epoch, evaluate
from sklearn.metrics import r2_score

torch.manual_seed(3407)
torch.cuda.manual_seed_all(3407)
torch.backends.cudnn.deterministic = True

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

# configs
in_dim = 100
embed_dim=32
out_dim = 1
depth_transformer=2
heads_transformer=8
n_epochs = 100
fine_tune_epochs=500
lr = 1e-3 
fine_tune_lr=7e-3 
lr_steps = [10, 30] 
lr_gamma = 0.1
batch_size = 256
fine_tune_batch_size=32
patience = 30
train_valid_name="Ecoli"
testname1="trc" 
Update_Train=True
Update_Test1=True

def main():
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    CGR_N=20
    if Update_Train==True:
        matrix_generation(train_valid_name,CGR_N)
    if Update_Test1==True:
        matrix_generation(testname1,CGR_N)

    train_dataset, val_dataset = get_dataset(path_x='./data/'+train_valid_name+'_seq.npy', path_pssm='./data/'+train_valid_name+'_matrix.npy',
                                             path_y='./data/'+train_valid_name+'_y.npy', path_w2v='./data/word2vec.npy',val_percentage=0.25)

    
    fine_tune_dataset,test_dataset=get_test_dataset(path_x='./data/'+testname1+'_seq.npy', path_pssm='./data/'+testname1+'_matrix.npy',
                                             path_y='./data/'+testname1+'_y.npy', path_w2v='./data/word2vec.npy',test_percentage=0.1, State=42)

    train_loader = DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(dataset=val_dataset, batch_size=len(val_dataset), shuffle=False)
    fine_tune_loader = DataLoader(dataset=fine_tune_dataset, batch_size=fine_tune_batch_size, shuffle=True) 
    test_loader= DataLoader(dataset=test_dataset, batch_size=len(test_dataset), shuffle=False)

    model = PrompterModel(input_dim=in_dim,
                          embedding_dim=embed_dim,
                          depth_transformer=2,
                          heads_transformer=8,
                          dim_head_transformer=64,
                          attn_dropout_transformer=0.1,
                          ff_dropout_transformer=0.1,
                          dropout_CNN=0.2,
                          mat_size=CGR_N
                          )
    
    model = model.to(device)

    print(f'The model has {count_parameters(model):,} trainable parameters')
    print(next(model.parameters()).device)

    optimizer = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.L1Loss()
    lr_scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=lr_steps,gamma=lr_gamma)
    monitor1 = -1
    monitor2 = -1
    bad_epochs = 0
    best_weight_dir1 = './best_Ecoli.pth'
    best_weight_dir2 = './best_trc.pth'

    for epoch in range(n_epochs):
        train_one_epoch(model=model, optimizer=optimizer, criterion=criterion,data_loader=train_loader, device=device)
        lr_scheduler.step()

        train_loss, train_acc, train_R2 = evaluate(model=model, data_loader=train_loader, criterion=criterion, device=device)
        print(
            'Epoch: [{}/{}], Train Loss: {:.4f}, Train acc: {:.4f}, Train R2: {:.4f}'.format(epoch, n_epochs, train_loss, train_acc, train_R2))
        
        
        valid_loss, valid_acc, valid_R2 = evaluate(model=model, data_loader=val_loader, criterion=criterion, device=device)
        print(
            'Epoch: [{}/{}], Val loss: {:.4f}, Val acc: {:.4f}, Val R2: {:.4f}'.format(epoch, n_epochs, valid_loss, valid_acc, valid_R2))
        
        if valid_acc > monitor1:
            torch.save(model.state_dict(), best_weight_dir1)
            print('Now best valid corr: {:.4f}, and best weight is saved in {}.'.format(valid_acc,best_weight_dir1))
            monitor1 = valid_acc
            monitor2 = valid_R2
            bad_epochs = 0
        else:
            print('No improved! Now best valid corr: {:.4f}, with corresponding R2: {:.4f}.'.format(monitor1, monitor2))
            bad_epochs += 1

        if bad_epochs >= patience:
            print('Early stop!')
            break

    # NN fine tune
    best_weight = torch.load(best_weight_dir1)
    model = PrompterModel(input_dim=in_dim,
                          embedding_dim=embed_dim,
                          depth_transformer=2,
                          heads_transformer=8,
                          dim_head_transformer=64,
                          attn_dropout_transformer=0.1,
                          ff_dropout_transformer=0.1,
                          dropout_CNN=0.2,
                          mat_size=CGR_N)
    model.load_state_dict(best_weight)
    for param in model.parameters():
        param.requires_grad = False


    model.output_layer = nn.Sequential(
    nn.Linear(16*CGR_N*CGR_N+48*embed_dim, 4*CGR_N*CGR_N+12*embed_dim), 
    nn.ReLU(),  
    nn.Linear(4*CGR_N*CGR_N+12*embed_dim, CGR_N*CGR_N+3*embed_dim), 
    nn.ReLU(),  
    nn.Linear(CGR_N*CGR_N+3*embed_dim, 124), 
    nn.ReLU(),  
    nn.Linear(124, 64), 
    nn.ReLU(),  
    nn.Linear(64, 32),
    nn.ReLU(),  
    nn.Linear(32, 8),
    nn.ReLU(),  
    nn.Linear(8, 1),
    )
    
    model = model.to(device)

    optimizer = optim.Adam(model.output_layer.parameters(), lr=fine_tune_lr)

    fine_tune_monitor1=-1
    fine_tune_monitor2=-1
    for epoch in range(fine_tune_epochs):
        train_one_epoch(model=model, optimizer=optimizer, criterion=criterion, data_loader=fine_tune_loader, device=device)
        fine_tune_loss, fine_tune_acc, fine_tune_R2 = evaluate(model=model, data_loader=fine_tune_loader, criterion=criterion, device=device)
        print('Fine_tune_Epoch: [{}/{}], Train Loss: {:.4f}, Train acc: {:.4f}, Train R2: {:.4f}'.format(epoch, fine_tune_epochs, fine_tune_loss, fine_tune_acc, fine_tune_R2))
        test_loss, test_acc, test_R2 = evaluate(model=model, data_loader=test_loader, criterion=criterion, device=device)
        print('Fine_tune_Epoch: [{}/{}], Test loss: {:.4f}, Test acc: {:.4f}, Test R2: {:.4f}'.format(epoch, fine_tune_epochs, test_loss, test_acc, test_R2))
        
        if test_R2 > fine_tune_monitor1:
            fine_tune_monitor1 = test_R2
            fine_tune_monitor2 = test_acc
            torch.save(model.state_dict(), best_weight_dir2)
        else:
            print('No improved! Now best R2: {:.4f}, with corresponding corr: {:.4f}.'.format(fine_tune_monitor1, fine_tune_monitor2))

if __name__ == '__main__':
    main()
